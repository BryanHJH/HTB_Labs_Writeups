<?php
system('"C:\\xampp\\mysql\\bin\\mysqldump.exe" -u certificate_webapp_user -pENTER-MY-SQL-DB-PASSWORD Certificate_WEBAPP_DB > C:\\xampp\\htdocs\\certificate.htb\\static\\full_dump.sql');
?>
