<?php

/**
 * @file
 * A cached plugin object that tests including.
 */

class pluginNotCachedPluginArray2 {}
